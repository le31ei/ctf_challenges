<?php
$con = mysql_connect('db','comment','comment');
mysql_query("set names utf8");
mysql_select_db("comment");
?>
