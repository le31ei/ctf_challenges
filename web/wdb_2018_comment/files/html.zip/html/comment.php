<!doctype html>
<html class="no-js" lang="">

<head>

    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1">

    <title>留言板</title>

<style type="text/css"> 
.AutoNewline 
{ 
  Word-break: break-all;
} 
</style>
    <link rel="stylesheet" href="/vendor/bootstrap-select/bootstrap-select.css">
    <link rel="stylesheet" href="/vendor/dropzone/dropzone.css">
    <link rel="stylesheet" href="/vendor/slider/slider.css">
    <link rel="stylesheet" href="/vendor/bootstrap-datepicker/datepicker.css">
    <link rel="stylesheet" href="/vendor/timepicker/jquery.timepicker.css">
    <link rel="stylesheet" href="/vendor/offline/theme.css">
    <link rel="stylesheet" href="/vendor/pace/theme.css">


    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/animate.min.css">

    <link rel="stylesheet" href="/css/panel.css">

    <link rel="stylesheet" href="/css/skins/palette.1.css" id="skin">
    <link rel="stylesheet" href="/css/fonts/style.1.css" id="font">
    <link rel="stylesheet" href="/css/main.css">

    <script src="/vendor/modernizr.js"></script>
</head>

<body>
<?php
include "mysql.php";
    $id = addslashes($_GET['id']);
    $sql = "select * from board where id='$id'";
    $result = mysql_query($sql);
    $row = mysql_fetch_array($result);
    $title = $row['title'];
    $content = $row['content'];
?>
            <section class="main-content">
                <div class="content-wrap">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="tab-content ">
                                <section class="tab-pane active">
                                            <section class="panel">
                                                <header class="panel-heading"><b><?=$title?></b></header>
                                                <div class="panel-body">
                                                    <form class="form-horizontal bordered-group" role="form" method="post" action="./write_do.php?do=comment" onsubmit="return submit_check()">
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label">正文</label>
                                                            <div class="col-sm-5">
                                                                <p><?=$content?></p>
                                                            </div>
                                                        </div>
<?php
    $sql = "select * from comment where bo_id='$id'";
    $result = mysql_query($sql);
    $num = mysql_num_rows($result);
    if($num>0){
    while($row= mysql_fetch_array($result)){
    echo '<div class="form-group">';
    echo '<label class="col-sm-2 control-label">留言</label>';
    echo '<div class="col-sm-5">';
    echo "<p>$row[content]</p>";
    echo '</div>';
    echo '</div>';
    }
    }

?>
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label">提交留言</label>
                                                            <div class="col-sm-5">
                                                                <textarea name="content" class="form-control" rows="8"></textarea>
                                                                <input hidden name="bo_id" value="<?=$id?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label"></label>
                                                            <div class="col-sm-10">
                                                                <button type="submit" class="btn btn-success"><i class="fa fa-check"></i>提交</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </section>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
        </section>


    <script src="/vendor/jquery-1.11.1.min.js"></script>
    <script src="/bootstrap/js/bootstrap.js"></script>
    <script src="/vendor/jquery.easing.min.js"></script>
    <script src="/vendor/jquery.placeholder.js"></script>
    <script src="/vendor/fastclick.js"></script>


    <script src="/vendor/bootstrap-select/bootstrap-select.js"></script>
    <script src="/vendor/dropzone/dropzone.js"></script>
    <script src="/vendor/parsley.min.js"></script>
    <script src="/vendor/fuelux/checkbox.js"></script>
    <script src="/vendor/fuelux/radio.js"></script>
    <script src="/vendor/fuelux/wizard.js"></script>
    <script src="/vendor/fuelux/pillbox.js"></script>
    <script src="/vendor/fuelux/spinner.js"></script>
    <script src="/vendor/slider/bootstrap-slider.js"></script>
    <script src="/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
    <script src="/vendor/wysiwyg/jquery.hotkeys.js"></script>
    <script src="/vendor/wysiwyg/bootstrap-wysiwyg.js"></script>
    <script src="/vendor/switchery/switchery.js"></script>
    <script src="/vendor/timepicker/jquery.timepicker.js"></script>
    <script src="/vendor/offline/offline.min.js"></script>
    <script src="/vendor/pace/pace.min.js"></script>

    <script src="/vendor/jquery.slimscroll.js"></script>
    <script src="/js/off-canvas.js"></script>
    <script src="/js/main.js"></script>

    <script src="/js/panel.js"></script>
    <script src="/js/forms.js"></script>
<script language="javascript">  
function submit_check(){
    var gnl=confirm("确定要提交?");
    if (gnl==true){
        return true;
    }
    else{
        return false;
    }
    }
</script> 
</body>
</html>
